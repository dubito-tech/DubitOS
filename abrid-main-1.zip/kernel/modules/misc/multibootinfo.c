#include <multibootinfo.h>

multiboot_info_t* mbi;