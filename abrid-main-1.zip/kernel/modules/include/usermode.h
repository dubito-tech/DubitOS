#ifndef __USERMODE_H
#define __USERMODE_H

void usermode_init();

#endif