#ifndef __LIBC_H
#define __LIBC_H

void libc_init();

#endif