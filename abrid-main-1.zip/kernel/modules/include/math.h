#ifndef __MATH_H
#define __MATH_H

#define MATH_ERRNO 1
#define MATH_ERREXCEPT 2

#endif
