#ifndef __STDIO_H
#define __STDIO_H

#define EOF -1


int puts(const char *s);

#endif