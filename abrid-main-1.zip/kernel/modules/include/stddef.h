#ifndef __STDDEF_H
#define __STDDEF_H

#define NULL ((char * ) 0)

typedef signed int ptrdiff_t;
typedef unsigned int size_t;

#endif