#ifndef __EXECUTE_H
#define __EXECUTE_H

void execute_program(char* filename);

#endif