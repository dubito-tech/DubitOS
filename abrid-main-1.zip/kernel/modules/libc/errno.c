#include <errno.h>

void errno_init() {
	errno = 0;
}