#ifndef __C4_H
#define __C4_H

int c4(int fd);

#endif